#' This is some description of this function.
#' @title R packages batch installation.
#' @description The function is batch installation dependence R packages.
#' @author Lin-Lin Gu
#' @export
ipak <- function(pkg){
  new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if(length(new.pkg))
    install.packages(new.pkg, dependencies = TRUE)
  sapply(pkg, require, character.only = TRUE)
}
#' This is some description of this function.
#' @title Welcome to PIXANT.
#' @description Just the welcome function that will appear every time that your run the program.
#' @author Lin-Lin Gu
#' @export
PIXANT.version <-function()
{
  message(paste("#", paste(rep("-", 30), collapse=""), "Welcome to PIXANT", paste(rep("-", 30), collapse=""), "#", sep=""), "")
  cat("#          _\\\\|//_                                                            #\n")
  cat("#         (^ o-o ^)                                                           #\n")
  cat("#========ooO-(_)-Ooo==========================================================#\n")
  cat("#                        Rapid and accurate multi-phenotype imputation        #\n")
  cat("#                               for millions of individuals.                  #\n")
  cat("#       .oooO    Oooo.              linlin-gu@outlook.com                     #\n")
  cat("#       (   )    (   )                  August,2023                           #\n")
  cat("#========\\ (======) /=================Version: 0.1.0==========================#\n")
  cat("#         \\_)    (_/                                                          #\n")
  message("#-----------------------------------------------------------------------------#\n")
}
#' This is some description of this function.
#' @title Generate Random Seed
#' @description This funcation is appplied for generating random seed with current system time
#' @author Lin-Lin Gu
#' @export
#' @return (numeric) A random seed
randomSeed <- function() {
  curtime <- format(Sys.time(), "%H:%M:%OS4")
  XXX <- unlist(strsplit(curtime, ":"))
  curtimeidx <- (as.numeric(XXX[1])*3600 + as.numeric(XXX[2])*60 + as.numeric(XXX[3]))*10000
  curtimeidx
}
#' This is some description of this function.
#' @title PIXANT evaluation indicator.
#' @description The function calculates correlation coefficient between imputed values and their true hidden values.
#' @param ximp The imputed data (a vector, matrix or data frame).
#' @param xmis The data with missing values.
#' @param xtrue The complete true data. (or any matrix to be compared with ximp)
#' @author Lin-Lin Gu
#' @export
#' @return Return the correlation coefficient between the real values and the imputed values.
#'
PIXANT.eval <- function(ximp, xmis, xtrue){
  mis <- is.na(xmis)
  cor(ximp[mis], xtrue[mis])
}
#' This is some description of this function.
#' @title The function imputed a large data with missing values using the PIXANT.
#' @description Imputing missing values by using the mixed fast random forest. The PIXANT method
#'              comprises two parts: 1) the estimation part: estimating parameters under the null
#'              model and applying the likelihood to correct for linear and nonlinear effects; 2) the
#'              imputation part: performing imputation for the missing values.
#' @param xmis A vector, matrix or data frame with missing values.
#' @param MaxIterations Stop after how many iterations (default = 20).
#' @param MaxIterations0 The maximum iteration times of mixed fast random forest (default = 20).
#' @param num.trees How many trees are grown in the mixed fast random forest (default = 100).
#' @param mtry How many variables should be tried randomly at each node.
#' @param initialLinearEffects The initial values for linear effects (default = 0).
#' @param ErrorTolerance The tolerance for log-likelihood (default = 0.001).
#' @param indPhen The columns of the target phenotype, and used only for cross-validation operation (default = NULL).
#' @param missingSize The missing values size of settings in the target data, and must be less than number of observed values of the target data (default = 500).
#' @param seed Random seed. Default is 123, which generates the seed from R. Set to 0 to ignore the R seed.
#' @param randomseed  Logical variable. The default value is FALSE.
#' @param replace (boolean) If TRUE bootstrap sampling (with replacements) is performed, else subsampling (without replacements).
#' @param decreasing (boolean) If TRUE the columns are sorted with decreasing amount of missing values
#' @param verbose (boolean) If TRUE then PIXANT returns error estimates, runtime and if available true error during iterations.
#' @param sampsize List of size(s) of sample to draw.
#' @param max.depth Maximal tree depth. A value of NULL or 0 (the default) corresponds to unlimited depth, 1 to tree stumps (1 split per tree).
#' @param xtrue The complete true data (a vector, matrix or data frame).
#' @author Lin-Lin Gu
#' @import ranger
#' @export
#' @examples
#' library("PIXANT")
#' data(demoData)
#' system.time(PIXANT.imp <- PIXANT(demoData, MaxIterations = 20, MaxIterations0 = 20, num.trees = 100, mtry = floor(sqrt(ncol(demoData))),
#'                                  initialLinearEffects = 0, ErrorTolerance = 0.001, indPhen = 7, missingSize = 500, seed = 123,
#'                                  randomseed = FALSE, replace = TRUE, decreasing = TRUE, verbose = TRUE, sampsize = NULL, max.depth = NULL, xtrue = NA))
#'
#' @return A list, the list contains:
#' \itemize{
#'    \item{PIXANT.imp$accuracy} Imputation accuracy of target phenotype.
#'    \item{PIXANT.imp$value} The missing data of settings in the target phenotype, including sample index, observed values and imputed values (a data frame).
#'    \item{PIXANT.imp$ximp} The imputed data (a vector, matrix or data frame).
#'    \item{PIXANT.imp$r2} The r square of fitting between observed values and imputed values in the target phenotype.
#'    \item{PIXANT.imp$pValue} The p value of fitting between observed values and imputed values in the target phenotype.
#' }
PIXANT <- function(xmis, MaxIterations = 20, MaxIterations0 = 20, num.trees = 100, mtry = floor(sqrt(ncol(xmis))),
                   initialLinearEffects = 0, ErrorTolerance = 0.001, indPhen = NULL, missingSize = 500,
                   seed = 123, randomseed = FALSE, replace = TRUE, decreasing = TRUE,verbose = TRUE, sampsize = NULL,
                   max.depth = NULL, xtrue = NA)
{ #' marker----------------------------------------------------------------------
  if(randomseed == TRUE){
    seed <- randomSeed()
  }
  options(warn = 0)
  PIXANT.version()
  if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
    }
  #' Initial checks
  stopifnot(is.data.frame(xmis), dim(xmis) >= 1L, is.numeric(MaxIterations0),
            is.numeric(num.trees), length(MaxIterations0) == 1L,
            MaxIterations0 >= 1L)
  #'
  n <- nrow(xmis)
  p <- ncol(xmis)
  rawdata <- xmis
  if (!is.null(indPhen)){
    list <- which(!is.na(xmis[,indPhen]))
    set.seed(seed)
    mis <- sample(list, size = missingSize, replace = FALSE)
    xmis[mis,indPhen] <- NA
  }
  #' Remove completely missing phenotypes
  if (any(apply(is.na(xmis), 2, sum) == n)){
    indCmis <- which(apply(is.na(xmis), 2, sum) == n)
    xmis <- xmis[,-indCmis]
    p <- ncol(xmis)
    cat('  removed phenotype(s)', indCmis, 'Due to the missingness of all entries\n')
  }
  #' Initial imputation
  ximp <- imputeUnivariate(xmis, seed =seed)
  #' ximp <- xmis
  #' for (t.co in 1:ncol(xmis)) {
  #'     ximp[is.na(xmis[,t.co]),t.co] <- mean(xmis[,t.co], na.rm = TRUE)
  #'     next()
  #' }
  #'
  #' Extract missingness pattern
  NAloc <- is.na(xmis)            #' where are missings
  noNAvar <- apply(NAloc, 2, sum) #' how many are missing in the vars
  sort.j <- order(noNAvar)        #' indices of increasing amount of NA in vars
  if(decreasing)
     sort.j <- rev(sort.j)
  sort.noNAvar <- noNAvar[sort.j]
  #'
  #' Output
  Ximp <- vector('list', MaxIterations0)
  #'
  #' Initialize parameters of interest
  iter <- 0
  convNew <- 0
  convOld <- Inf
  names(convNew) <- c('numeric')
  convergence <- c()
  #'
  #' Function to yield the stopping criterion in the following 'while' loop
  stopCriterion <- function(convNew, convOld, iter, MaxIterations){
    (convNew < convOld) & (iter < MaxIterations)
  }
  #'
  #' Iterate PIXANT
  while (stopCriterion(convNew, convOld, iter, MaxIterations)){
    if (iter != 0){
      convOld <- convNew
    }
    cat("PIXANT iteration", iter+1, "in progress:", sep = " ")
    t.start <- proc.time()
    ximp.old <- ximp
    for(s in 1:p){
      varInd <- sort.j[s]
      if(noNAvar[[varInd]] != 0){
        obsi <- !NAloc[, varInd]
        misi <- NAloc[, varInd]
        obsY <- ximp[obsi, varInd]
        obsX <- ximp[obsi, seq(1, p)[-varInd]]
        misX <- ximp[misi, seq(1, p)[-varInd]]
        #'
        Target = obsY
        #' Condition that indicates the loop has not converged or run out of iterations
        ContinueCondition = TRUE
        iterations <- 0
        #'
        #' Get initial values
        #'
        AdjustedTarget <- Target - initialLinearEffects
        oldLogLik <- -Inf
        while(ContinueCondition){
          iterations <- iterations + 1
          FRF <- ranger(x = obsX,
                        y = AdjustedTarget,
                        num.trees = num.trees,
                        mtry = mtry,
                        max.depth = max.depth,
                        replace = TRUE,
                        splitrule = "variance",
                        write.forest = TRUE,
                        min.node.size = 5,
                        oob.error = TRUE,
                        seed = seed)
          #' y - u (out-of-bag prediction)
          resi = Target - FRF$predictions
          #' Estimate new linear effects and errors using glm
          newData <- data.frame(resi, obsX)
          n_cov <- ncol(newData)
          xnam <- paste(colnames(newData)[2:n_cov], sep="", collapse="+")
          fmla <- as.formula(paste("resi ~ -1 + ", paste(xnam, collapse= "+")))
          glmfit <- glm(formula = fmla, data = newData)
          #'
          #' Check convergence
          newLogLik <- as.numeric(logLik(glmfit))
          ContinueCondition <- (abs(newLogLik - oldLogLik) > ErrorTolerance & iterations < MaxIterations0)
          oldLogLik <- newLogLik
          #' Extract linear effects to make the new adjusted target
          LinearEffects <- predict(glmfit, obsX)
          #' y - X*b
          AdjustedTarget <- Target - LinearEffects
        }
        NonlinearEffects <- predict(FRF, misX)
        Linear_Effects <- predict(glmfit, misX)
        misY <-  NonlinearEffects$predictions + Linear_Effects
        ximp[misi, varInd] <- misY
      }
      cat(".")
    }
    cat("\nIteration", iter+1, "completed\n")
    iter <- iter + 1
    Ximp[[iter]] <- ximp
    #'
    #' Check the difference between iteration steps
    convNew <- sum((ximp - ximp.old)^2)/sum(ximp^2)
    if(any(!is.na(xtrue))){
      err <- suppressWarnings(PIXANT.eval(ximp, xmis, xtrue))
    }
    #' Return status output, if desired
    if(verbose){
      delta.start <- proc.time() - t.start
      if(any(!is.na(xtrue))){
        cat("Error(s):", err, "\n")
      }
      cat("ConvNew difference(s):", convNew, "\n")
      cat("       Time consuming:", delta.start[3],"seconds\n\n")
    }
  }
  #'
  #' marker----------------------------------------------------------------------
  #' Produce output w.r.t. stopping rule
  if(iter == MaxIterations0){
    if(any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter]])
    }else{
      out <- list(ximp = Ximp[[iter]], error = err)
    }
  }else{
    if(any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter - 1]])
    }else{
      out <- list(ximp = Ximp[[iter - 1]],
                  error = suppressWarnings(PIXANT.eval(Ximp[[iter - 1]], xmis, xtrue)))
    }
  }
  if(!is.null(indPhen)){
    #' save results
    out$accuracy <- cor(out$ximp[mis, indPhen], rawdata[mis, indPhen])
    out$value <- as.data.frame(cbind(mis, rawdata[mis, indPhen], out$ximp[mis, indPhen]))
    names(out$value) <- c("indSample", "Observed", "Imputed")
    fit <- lm(out$value$Observed ~ out$value$Imputed)
    out$r2 <- summary(fit)$r.squared
    out$pValue <- 1-pf(summary(fit)$fstatistic[1], summary(fit)$fstatistic[2], summary(fit)$fstatistic[3])
    out$ximp[mis, indPhen] <- rawdata[mis, indPhen]
  }else{
    cat('Due to the missingness of indPhen, the results(i.e, accuracy, value, r2 and pValue) are NULL\n')
  }
  class(out) <- 'PIXANT'
  return(out)
}
