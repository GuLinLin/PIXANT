#' This is some description of this function.
#' @title Welcome to PIXANT.
#' @description Just the welcome function that will appear every time that your run the program.
#' @author Lin-Lin Gu
#' @export
PIXANT.version <- function()
{
  cat(paste("#", paste(rep("=", 18), collapse=""), "Welcome to PIXANT", paste(rep("=", 18), collapse=""), "#", sep=""), "\n")
  cat("#       ____ _____  __    _    _   _ _____            #\n")
  cat("#       |  _ \\_ _\\ \\/ /   / \\  | \\ | |_   _|          #\n")
  cat("#       | |_) | | \\  /   / _ \\ |  \\| | | |            #\n")
  cat("#       |  __/| | /  \\  / ___ \\| |\\  | | |            #\n")
  cat("#       |_|  |___/_/\\_\\/_/   \\_\\_| \\_| |_|            #\n")
  cat("#   Rapid and accurate multi-phenotype imputation     #\n")
  cat("#          for millions of individuals.               #\n")
  cat("#  Authors: L.-L. Gu, M. Fang, D. Jiang, G.-B. Chen   #\n")
  cat("#               Version: 0.1.0                        #\n")
  cat("#    How to access help: linlin-gu@outlook.com        #\n")
  cat("#   Website: https://github.com/GuLinLin/PIXANT       #\n")
  cat(paste("#", paste(rep("=", 53), collapse=""), "#", sep=""), "\n")
}
#' This is some description of this function.
#' @title PIXANT evaluation indicator.
#' @description The function calculates correlation coefficient between imputed values and their true hidden values.
#' @param ximp The imputed data (a vector, matrix or data frame).
#' @param xmis The data with missing values.
#' @param xtrue The complete true data. (or any matrix to be compared with ximp)
#' @author Lin-Lin Gu
#' @export
#' @return Return the correlation coefficient between the real values and the imputed values.
#'
PIXANT.eval <- function(ximp, xmis, xtrue){
  mis <- is.na(xmis)
  cor(ximp[mis], xtrue[mis])
}
#' This is some description of this function.
#' @title The function imputed a large data with missing values using the PIXANT.
#' @description Imputing missing values by using the mixed fast random forest. The PIXANT method
#'              comprises two parts: 1) the estimation part: estimating parameters under the null
#'              model and applying the likelihood to correct for linear and nonlinear effects; 2) the
#'              imputation part: performing imputation for the missing values.
#' @param data A data frame with missing values.
#' @param aimPhenName The column name for the imputed phenotype.
#' @param maxIterations Stop after how many iterations (default = 20).
#' @param maxIterations0 The maximum iteration times of mixed fast random forest (default = 20).
#' @param num.trees How many trees are grown in the mixed fast random forest (default = 100).
#' @param initialLinearEffects The initial values for linear effects (default = 0).
#' @param errorTolerance The tolerance for log-likelihood (default = 0.001).
#' @param aimPhenMissingSize The missing values size of settings in the imputed phenotype, and must be less than number of observed values of the imputed phenotype (default = 500).
#' @param initialImputeType Initial imputation method for missing values in a data frame. Currently support: "random", "average", "median".
#' @param refPhenThreshold Relevance threshold for the selection of reference phenotypes, the range from 0 to 1 (default = 0.3).
#' @param maxNum.refPhen Maximum number of reference phenotypes to be selected (default = 10).
#' @param SC.Threshold Individual's imputation quality threshold (default = 0.6).
#' @param seed Random seed. Default is 123, which generates the seed from R. Set to 0 to ignore the R seed.
#' @param decreasing (boolean) If TRUE the columns are sorted with decreasing amount of missing values
#' @param verbose (boolean) If TRUE then PIXANT returns error estimates, runtime and if available true error during iterations.
#' @param xtrue The complete true data (a vector, matrix or data frame).
#' @author Lin-Lin Gu
#' @import ranger
#' @export
#' @examples
#' library("PIXANT")
#' data(demoData)
#' system.time(PIXANT.imp <- PIXANT(demoData, aimPhenName = 'Phenotype7', maxIterations = 2, maxIterations0 = 2,
#'                                  num.trees = 100, initialLinearEffects = 0, errorTolerance = 0.001,
#'                                  aimPhenMissingSize = 500, initialImputeType = 'random', refPhenThreshold = 0.3,
#'                                  maxNum.refPhen = 7, SC.Threshold = 0.6, seed = 123))
#'
#' @return A list, the list contains:
#' \itemize{
#'    \item{PIXANT.imp$imputePhen.accuracy} Imputation accuracy of imputed phenotype.
#'    \item{PIXANT.imp$imputePhen.value} The missing data of settings in the imputed phenotype, including sample index, observed values and imputed values (a data frame).
#'    \item{PIXANT.imp$ximp} The imputed data (a data frame).
#'    \item{PIXANT.imp$imputePhen.r2} The r square of fitting between observed values and imputed values in the target phenotype.
#'    \item{PIXANT.imp$imputePhen.pValue} The p value of fitting between observed values and imputed values in the target phenotype.
#'    \item{PIXANT.imp$imputePhen.refPhen} A data frame of reference phenotypes for impute phenotype.
#'    \item{PIXANT.imp$imputePhen.missingRate} Original missing rate of the imputed phenotypes.
#'    \item{PIXANT.imp$imputePhen} the impute phenotype, including imputed values and SC for each samples (a data frame).
#'    \item{PIXANT.imp$imputePhen.filter.missingRate} Missing rate after SC quality control of the imputed phenotype.
#' }
PIXANT <- function(data, aimPhenName, maxIterations = 20, maxIterations0 = 20, num.trees = 100,
                   initialLinearEffects = 0, errorTolerance = 0.001, aimPhenMissingSize = 500,
                   initialImputeType = 'random', refPhenThreshold = 0.3, maxNum.refPhen = 10,
                   SC.Threshold = 0.6, seed = 123, decreasing = TRUE, verbose = TRUE, xtrue = NA)
{ # marker
  options(warn = 0)
  PIXANT.version()
  if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
  }
  if(!require(psych)){
    install.packages("psych")
    library(psych)
  }
  # Initial checks
  stopifnot(is.data.frame(data), dim(data) >= 1L, is.numeric(maxIterations), is.numeric(maxIterations0),
            is.numeric(num.trees), is.numeric(initialLinearEffects), is.numeric(errorTolerance),
            is.character(aimPhenName), is.numeric(aimPhenMissingSize), is.numeric(refPhenThreshold),
            is.numeric(maxNum.refPhen), is.numeric(SC.Threshold), length(maxIterations) == 1L,
            length(maxIterations0) == 1L, refPhenThreshold >=0L, refPhenThreshold <=1L,
            SC.Threshold >=0L, SC.Threshold <=1L, maxIterations >= 1L, maxIterations0 >= 1L)
  if(!aimPhenName %in% colnames(data)) {
    stop("The phenotype name is error. Please check it again.")
  }
  # Remove completely missing phenotypes
  if (any(apply(is.na(data), 2, sum) == nrow(data))){
    indCmis <- which(apply(is.na(data), 2, sum) == nrow(data))
    data <- data[,-indCmis]
    cat('Removed phenotype(s)', indCmis, 'Due to the missingness of all entries\n')
  }
  cat("\nStep 1: Reference phenotypes selection", sep = " ")
  selected_column <- as.numeric(as.matrix(data[colnames(data) == aimPhenName]))
  df = data[, -which(colnames(data) == aimPhenName)]
  refPhenCorr <- data.frame(matrix(nrow = ncol(df), ncol = 2))
  colnames(refPhenCorr) <- c('ref.Phenotype', 'correlation')
  for(s in 1:ncol(df)){
    tryCatch({
      cor_results <- cor.test(as.numeric(df[,s]), selected_column, na.rm = TRUE)
    }, error = function(e){
      cor_coefficients <- t(matrix(c(colnames(df)[s],NA)))
    })
    cor_coefficients <- t(matrix(c(colnames(df)[s], cor_results$estimate)))
    refPhenCorr[s,] <- cor_coefficients
    #if(s %% 100 == 0){
    #  cat(".")
    #}
  }
  refPhenCorr <- refPhenCorr[!is.na(refPhenCorr$correlation),]
  refPhenCorr.sort <- refPhenCorr[order(-abs(as.numeric(refPhenCorr$correlation))),]
  if(nrow(refPhenCorr[abs(as.numeric(refPhenCorr$correlation)) >= refPhenThreshold,])==0L) {
    stop(aimPhenName, ": Phenotype cannot be imputed, due to the missingness of reference phenotypes.")
  }
  ref.phenotypes <- refPhenCorr.sort[1:maxNum.refPhen,]
  cat("\n        Task completed, reference phenotypes are", ref.phenotypes$ref.Phenotype, "\n\n")
  #
  cat("\nStep 2: Data preparation for imputing", sep = " ")
  xmis <- data[,c(aimPhenName, colnames(data)[colnames(data) %in% ref.phenotypes$ref.Phenotype]),drop = FALSE]
  #
  n <- nrow(xmis)
  p <- ncol(xmis)
  rawdata <- xmis
  list <- which(!is.na(xmis[,aimPhenName]))
  set.seed(seed)
  mis <- sample(list, size = aimPhenMissingSize, replace = FALSE)
  xmis[mis,aimPhenName] <- NA
  # Initial imputation
  ximp <- imputeUnivariate(xmis, initialImputeType = initialImputeType, seed =seed)
  # ximp <- xmis
  # for (t.co in 1:ncol(xmis)) {
  #     ximp[is.na(xmis[,t.co]),t.co] <- mean(xmis[,t.co], na.rm = TRUE)
  #     next()
  # }
  #
  # Extract missingness pattern
  NAloc <- is.na(xmis)            # where are missings
  noNAvar <- apply(NAloc, 2, sum) # how many are missing in the vars
  sort.j <- order(noNAvar)        # indices of increasing amount of NA in vars
  if(decreasing)
    sort.j <- rev(sort.j)
  sort.noNAvar <- noNAvar[sort.j]
  #
  # Output
  Ximp <- vector('list', maxIterations0)
  #
  # Initialize parameters of interest
  iter <- 0
  convNew <- 0
  convOld <- Inf
  names(convNew) <- c('numeric')
  convergence <- c()
  #
  # Function to yield the stopping criterion in the following 'while' loop
  stopCriterion <- function(convNew, convOld, iter, maxIterations){
    (convNew < convOld) & (iter < maxIterations)
  }
  cat("\n        Task completed, the data to be imputed has", n, "rows and", p, "columns.\n\n")
  #
  cat("\nStep 3: Multi-phenotype imputation", sep = " ")
  # Iterate PIXANT
  while (stopCriterion(convNew, convOld, iter, maxIterations)){
    if (iter != 0){
      convOld <- convNew
    }
    cat("\n        PIXANT iteration", iter+1, "in progress:", sep = " ")
    t.start <- proc.time()
    ximp.old <- ximp
    for(s in 1:p){
      varInd <- sort.j[s]
      if(noNAvar[[varInd]] != 0){
        obsi <- !NAloc[, varInd]
        misi <- NAloc[, varInd]
        obsY <- ximp[obsi, varInd]
        obsX <- ximp[obsi, seq(1, p)[-varInd]]
        misX <- ximp[misi, seq(1, p)[-varInd]]
        #
        Target = obsY
        # Condition that indicates the loop has not converged or run out of iterations
        ContinueCondition = TRUE
        iterations <- 0
        #
        # Get initial values
        #
        AdjustedTarget <- Target - initialLinearEffects
        oldLogLik <- -Inf
        while(ContinueCondition){
          iterations <- iterations + 1
          FRF <- ranger(x = obsX,
                        y = AdjustedTarget,
                        num.trees = num.trees,
                        mtry = floor(sqrt(ncol(obsX))),
                        max.depth = NULL,
                        replace = TRUE,
                        splitrule = "variance",
                        write.forest = TRUE,
                        min.node.size = 5,
                        oob.error = TRUE,
                        seed = seed)
          # y - u (out-of-bag prediction)
          resi = Target - FRF$predictions
          # Estimate new linear effects and errors using glm
          newData <- data.frame(resi, obsX)
          n_cov <- ncol(newData)
          xnam <- paste(colnames(newData)[2:n_cov], sep="", collapse="+")
          fmla <- as.formula(paste("resi ~ -1 + ", paste(xnam, collapse= "+")))
          glmfit <- glm(formula = fmla, data = newData)
          #
          # Check convergence
          newLogLik <- as.numeric(logLik(glmfit))
          ContinueCondition <- (abs(newLogLik - oldLogLik) > errorTolerance & iterations < maxIterations0)
          oldLogLik <- newLogLik
          # Extract linear effects to make the new adjusted target
          LinearEffects <- predict(glmfit, obsX)
          # y - X*b
          AdjustedTarget <- Target - LinearEffects
        }
        NonlinearEffects <- predict(FRF, misX)
        Linear_Effects <- predict(glmfit, misX)
        misY <-  NonlinearEffects$predictions + Linear_Effects
        ximp[misi, varInd] <- misY
      }
      cat(".")
    }
    cat("\n        Iteration", iter+1, "completed\n")
    iter <- iter + 1
    Ximp[[iter]] <- ximp
    #
    # Check the difference between iteration steps
    convNew <- sum((ximp - ximp.old)^2)/sum(ximp^2)
    if(any(!is.na(xtrue))){
      err <- suppressWarnings(PIXANT.eval(ximp, xmis, xtrue))
    }
    # Return status output, if desired
    if(verbose){
      delta.start <- proc.time() - t.start
      if(any(!is.na(xtrue))){
        cat("Error(s):", err, "\n")
      }
      cat("        ConvNew difference(s):", convNew, "\n")
      cat("               Time consuming:", delta.start[3],"seconds\n")
    }
  }
  #
  # Produce output w.r.t. stopping rule
  if(iter == maxIterations0){
    if(any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter]])
    }else{
      out <- list(ximp = Ximp[[iter]], error = err)
    }
  }else{
    if(any(is.na(xtrue))){
      out <- list(ximp = Ximp[[iter - 1]])
    }else{
      out <- list(ximp = Ximp[[iter - 1]],
                  error = suppressWarnings(PIXANT.eval(Ximp[[iter - 1]], xmis, xtrue)))
    }
  }
  cat("\n        Task completed.\n\n")
  cat("\nStep 4: Calculate the SC of", aimPhenName, sep = " ")
  sample_scores <- SC(Phen=rawdata, aimPhenName=aimPhenName)
  cat("\n        Task completed.\n\n")
  #
  cat("\nStep 5: The results of PIXANT are being saved", sep = " ")
  # save results
  #
  out$imputePhen.accuracy <- cor(out$ximp[mis, aimPhenName], rawdata[mis, aimPhenName])
  out$imputePhen.value <- as.data.frame(cbind(mis, rawdata[mis, aimPhenName], out$ximp[mis, aimPhenName]))
  names(out$imputePhen.value) <- c("indSample", "Observed", "Imputed")
  fit <- lm(out$imputePhen.value$Observed ~ out$imputePhen.value$Imputed)
  out$imputePhen.r2 <- summary(fit)$r.squared
  out$imputePhen.pValue <- 1-pf(summary(fit)$fstatistic[1], summary(fit)$fstatistic[2], summary(fit)$fstatistic[3])
  out$imputePhen.refPhen <- ref.phenotypes
  out$imputePhen.missingRate <- sum(is.na(rawdata[,aimPhenName]))/length(rawdata[,aimPhenName])
  out$ximp[mis, aimPhenName] <- rawdata[mis, aimPhenName]
  #
  out$imputePhen <- cbind(out$ximp[, aimPhenName], sample_scores)
  names(out$imputePhen) <- c(aimPhenName, "SC")
  if(!is.null(rownames(rawdata))){
    rownames(out$imputePhen) <- rownames(rawdata)
  }else{
    rownames(out$imputePhen) <- paste0('Sample_',rep(1:n))
  }
  out$imputePhen[out$imputePhen$SC < SC.Threshold, aimPhenName] <- NA
  out$imputePhen.filter.missingRate <- sum(is.na(out$imputePhen[,aimPhenName]))/length(out$imputePhen[,aimPhenName])
  cat("\n        Task completed.\n")
  class(out) <- 'PIXANT'
  return(out)
}
