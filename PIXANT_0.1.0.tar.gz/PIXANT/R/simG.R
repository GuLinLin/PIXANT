#' This is some description of this function.
#' @title Simulated Genome Relationship Matrix.
#' @description The function simulates the construction of a genome relational matrix.
#' @param N The number of individuals and must be a positive integer.
#' @param k Coefficient of kinship and the value ranges from 0 to 1.
#' @param fam_size The size of the family, fam_size must be a positive integer and must divide N.
#' @author Lin-Lin Gu
#' @export
#' @return Genome Relationship Matrix.
#'
simG <- function(N, k, fam_size=6){
  if(N != abs(round(N)))
    stop('N must be a positive integer')
  if(fam_size != abs(round(fam_size)))
    stop('fam_size must be a positive integer')
  num_fams <- N / fam_size
  if(num_fams != round(num_fams))
    stop('fam_size must divide N')
  G <- matrix(0, N, N)
  for(family in 1:num_fams){
    fam_inds <- (family - 1) * fam_size + 1:fam_size
    G[fam_inds, fam_inds] <- k
  }
  diag(G) <- 1
  return(G)
}
