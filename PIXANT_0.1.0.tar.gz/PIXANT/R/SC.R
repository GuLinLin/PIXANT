#' This is some description of this function.
#' @title QC
#' @description Estimating the SC (Sample Score) for aim phenotype of each individual.
#' @param Phen Phenotype file. The missing values should be denoted by NA.
#' @param initialImputeType Initial imputation method for missing values in a data frame. Currently support: "random", "average", "median".
#' @param use use="pairwise" is the default value and will do pairwise deletion of cases. use="complete" will select just complete cases.
#' @param method method="pearson" is the default value. The alternatives to be passed to cor are "spearman" and "kendall". These last two are much slower, particularly for big data sets.
#' @param adjust What adjustment for multiple tests should be used? ("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"). See p.adjust for details about why to use "holm" rather than "bonferroni").
#' @param alpha alpha level of confidence intervals.
#' @author Lin-Lin Gu
SC <- function(Phen, aimPhenName, use="pairwise", method="pearson", adjust="fdr", alpha=.05){
  # sample score
  if(!require(psych)){
    install.packages("psych")
    library(psych)
  }
  n <- nrow(Phen)
  p <- ncol(Phen)
  # Find the correlations, sample sizes, and probability values between elements of a matrix or data.frame.
  cor.r <- corr.test(Phen, use = use, method = method, adjust = adjust, alpha = alpha)
  # marker
  score <- function(data, aimPhenName){
    if(!is.na(data[aimPhenName])){
      SC <- 1
    }else{
      list <- which(!is.na(data[, !(colnames(data) %in% aimPhenName)]))
      SC <- sum(cor.r$r[aimPhenName,!(colnames(data) %in% aimPhenName)][list]^2)/sum(cor.r$r[aimPhenName,!(colnames(data) %in% aimPhenName)]^2)
    }
    return(SC)
  }
  sample_score <- data.frame(matrix(nrow = n, ncol = 1))
  for (i in 1:n) {
    sample_score[i,] <- score(Phen[i,], aimPhenName)
  }
  colnames(sample_score) <- paste0(aimPhenName,'.SC')
  if(!is.null(rownames(Phen))){
    rownames(sample_score) <- rownames(Phen)
  }else{
    rownames(sample_score) <- paste0('Sample_',rep(1:n))
  }
  return(sample_score)
}
