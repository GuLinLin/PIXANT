#' This is some description of this function.
#' @title Phenotype adjust
#' @description Adjusted phenotypic values base on covariates.
#' @param Phen A vector, matrix or data frame with missing values.
#' @param Cov A matrix of covariates. Each row is a sample and each column corresponds to one covariate. For example, age, gender.
#' @author Lin-Lin Gu
#' @export
#'
PhenAdj <- function(Phen, Cov){
  #'
  n <- nrow(Phen)
  p <- ncol(Phen)
  NewPhen <- matrix(data = NA, nrow = n, ncol = p)
  for(i in 1:p){
    data = data.frame(trait = Phen[,i], cov)
    n_cov <- ncol(data)
    xnam <- paste(colnames(data)[2:n_cov], sep = "", collapse = "+")
    fmla <- as.formula(paste("trait ~ ", paste(xnam, collapse = "+")))
    Phen_res = residuals(lm(formula = fmla, data = data, na.action=na.exclude))
    Phen_inv = qnorm((rank(Phen_res, na.last="keep")-0.5) / length(na.omit(Phen_res)))
    NewPhen[,i] <- Phen_inv
  }
  if(!is.null(colnames(Phen))){
    colnames(NewPhen) <- colnames(Phen)
  }
  if(!is.null(rownames(Phen))){
    rownames(NewPhen) <- rownames(Phen)
  }
  return(NewPhen)
}
