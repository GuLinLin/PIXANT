#' This is some description of this function.
#' @title QC
#' @description Estimating the SC (Sample Score) for each phenotype of each individual.
#' @param Phen Phenotype file. The missing values should be denoted by NA.
#' @param use use="pairwise" is the default value and will do pairwise deletion of cases. use="complete" will select just complete cases.
#' @param method method="pearson" is the default value. The alternatives to be passed to cor are "spearman" and "kendall". These last two are much slower, particularly for big data sets.
#' @param adjust What adjustment for multiple tests should be used? ("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"). See p.adjust for details about why to use "holm" rather than "bonferroni").
#' @param alpha alpha level of confidence intervals.
#' @author Lin-Lin Gu
sampleScore <- function(Phen, use="pairwise", method="pearson", adjust="fdr", alpha=.05){
  #' sample score
  if(!require(psych)){
    install.packages("psych")
    library(psych)
  }
  n <- nrow(Phen)
  p <- ncol(Phen)
  #' Find the correlations, sample sizes, and probability values between elements of a matrix or data.frame.
  cor.r <- corr.test(Phen, use = use, method = method, adjust = adjust, alpha = alpha)
  #' marker-------------------------------------------
  score <- function(data){
    SC <- data.frame(matrix(ncol = p, nrow = 1))
    for (i in 1:p) {
      if(!is.na(data[i])){
        SC[i] <- 1
      }else{
        list<-which(!is.na(data[-i]))
        SC[i] <- sum(cor.r$r[i,-i][list]^2)/sum(cor.r$r[i,-i]^2)
      }
    }
    return(SC)
  }
  #' marker-------------------------------------------
  sample_score <- data.frame(matrix(ncol = p, nrow = n))
  for (i in 1:n) {
    sample_score[i,] <- score(Phen[i,])
  }
  if(!is.null(colnames(Phen))){
    colnames(sample_score) <- colnames(Phen)
  }
  if(!is.null(rownames(Phen))){
    rownames(sample_score) <- rownames(Phen)
  }
  return(sample_score)
}
