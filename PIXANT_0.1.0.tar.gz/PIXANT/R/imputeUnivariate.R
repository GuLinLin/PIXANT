#' This is some description of this function.
#' @title Univariate imputation.
#' @description Fills missing values of a vector, matrix or data frame by sampling with replacement from the non-missing values. For data frames, this sampling is done within column.
#' @param x A data frame.
#' @param initialImputeType Initial imputation method for missing values in a data frame. Currently support: "random", "average", "median".
#' @param v A character vector of column names to impute (only relevant if x is a data frame). The default NULL imputes all columns.
#' @param seed An integer seed.
#' @author Lin-Lin Gu
#' @export
#' @return x with imputed values.
#'
imputeUnivariate <- function(x, initialImputeType, v = NULL, seed = NULL){
  stopifnot(is.atomic(x) || is.data.frame(x))
  if(!is.null(seed)){
    set.seed(seed)
  }
  random.imputeVec <- function(z){
    na <- is.na(z)
    if((s <- sum(na))){
      if(s == length(z)){
        stop("No non-missing elements to sample from.")
      }
      z[na] <- sample(z[!na], s, replace = TRUE)
    }
    z
  }
  #
  average.imputeVec <- function(z, initialImputeType){
    na <- is.na(z)
    if((s <- sum(na))){
      if(s == length(z)){
        stop("No non-missing elements to sample from.")
      }
      z[na] <- mean(z[!na])
    }
    z
  }
  #
  median.imputeVec <- function(z, initialImputeType){
    na <- is.na(z)
    if((s <- sum(na))){
      if(s == length(z)){
        stop("No non-missing elements to sample from.")
      }
      z[na] <- median(z[!na])
    }
    z
  }
  #' vector or matrix
  if(is.atomic(x)){
    return(imputeVec(x))
  }
  #' data frame
  v <- if (is.null(v)) names(x) else intersect(v, names(x))
  if(initialImputeType == 'random'){
    x[, v] <- lapply(x[, v, drop = FALSE], random.imputeVec)
  }else if(initialImputeType == 'average'){
    x[, v] <- lapply(x[, v, drop = FALSE], average.imputeVec)
  }else if(initialImputeType == 'median'){
    x[, v] <- lapply(x[, v, drop = FALSE], median.imputeVec)
  }
  x
}
